import json
import requests

request = requests.get('https://api.github.com/repos/ggoraa/GLaDOS/releases/latest')
print(request)